import itertools,os,shutil

foundN64line = 0
N64_Rom_CRC = ""
with open('surreal.ini','r') as ini:
	for line in itertools.islice(ini,0,None):
		if line.lower().startswith('['):

			N64ID = line.lower().strip()[1:-6]
			N64ID1, N64ID2 = N64ID.split('-')
			
			File_Name = ini.next().replace('Game Name=','').strip()
			File_Name = File_Name.lower()
			# Fixed names for roms not matching internal names, I don't do crc checks so this needs done.
			if File_Name == "airboarderj (pj64x14-5.10)":
				File_Name = "airboarderjap (pj64x14-5.10)"
			if File_Name == "autolamborghini (pj64x14-612)":
				File_Name = "autolamborghini (pj64x14-6.12)"
			if File_Name == "duke nukem zh (1964-6.12)":
				File_Name = "dukenukemzh (1964-6.12)"
			if File_Name == "pokemonstadiumkazio (1964-5.60)":
				File_Name = "pokemonstadiumkaizo (1964-5.60)"
			if File_Name == "rakugakids (pj64x14-6.12)":
				File_Name = "rakuga kids (pj64x14-6.12)"
			if File_Name == "razorfreestylescooter (pj64x14-5.10)":
				File_Name = "razor scooter (pj64x14-5.10)"
			if File_Name == "scooby-doo (1964-612)":
				File_Name = "scooby-doo (1964-6.12)"
			if File_Name == "shufflepuckhomebrew (1964x11-6.11)":
				File_Name = "shufflepuck (1964x11-6.11)"
			if File_Name == "sm64 maker1.3 (pj64x14-5.10)":
				File_Name = "supermariomaker1.3 (pj64x14-5.10)"
			if File_Name == "sm64 ms (pj64x14-5.10)":
				File_Name = "supermarioms hack (pj64x14-5.10)"
			if File_Name == "sm64 ocarina (pj64x14-5.10)":
				File_Name = "supermarioocarina (pj64x14-5.10)"
			if File_Name == "sm64 od v5 (1964-5.10)":
				File_Name = "supermarioodysseyv5 (1964-5.10)"
			if File_Name == "sm64 sr (pj64x14-5.10)":
				File_Name = "supermariosr hack (pj64x14-5.10)"
			if File_Name == "snowboard kids 2 (1964-5.10)":
				File_Name = "snowboard kids 2 (pj64x14-5.10)"
			if File_Name == "space station sv (1964x11-5.31)":
				File_Name = "spacestationsv (1964x11-5.31)"
			
			N64_Rom_Name = ini.next().split('=')[1].strip()

			for N64_txt in os.listdir('txt_files'):
				N64_txt = N64_txt.lower()
				if N64ID1 in N64_txt or N64ID2 in N64_txt:
					if os.path.isfile(os.path.join('txt_files',N64ID1+'.txt')):
						N64_Rom_CRC = N64ID1
					if os.path.isfile(os.path.join('txt_files',N64ID2+'.txt')):
						N64_Rom_CRC = N64ID2
				
		print "File: " + File_Name
		print "Name: " + N64_Rom_Name
		print "CRC: " + N64_Rom_CRC
		print ""
		
		try:
			shutil.copy2(os.path.join('artwork',File_Name+'.png'), N64_Rom_CRC+'.jpg')
		except: pass
		
		# with open(os.path.join('box2dfront',N64_Rom_CRC+'.txt'), 'r') as f:
			# input = f.readlines()
		# input[0] = 'Filename: '+File_Name+'\nName: '+N64_Rom_Name+'\n'
		# input[0] = 'Name: '+N64_Rom_Name+'\n'
		
		# with open(N64_Rom_CRC+'.txt', 'w') as f:
			# f.writelines(input)
		
		
		try:
			ini.next() # skip the comment line
			ini.next() # skip the blank line
		except: pass