import itertools,os,shutil

foundN64line = 0
N64_Rom_CRC = ""
with open('surreal.ini','r') as ini:
	for line in itertools.islice(ini,0,None):
		if line.lower().startswith('['):

			N64ID = line.lower().strip()[1:-6]
			N64ID1, N64ID2 = N64ID.split('-')
			
			File_Name = ini.next().replace('Game Name=','').strip()
			File_Name = File_Name.lower()			
			
			N64_Rom_Name = ini.next().split('=')[1].strip()

			for N64_txt in os.listdir('txt_files'):
				N64_txt = N64_txt.lower()
				if N64ID1 in N64_txt or N64ID2 in N64_txt:
					if os.path.isfile(os.path.join('txt_files',N64ID1+'.txt')):
						N64_Rom_CRC = N64ID1
					if os.path.isfile(os.path.join('txt_files',N64ID2+'.txt')):
						N64_Rom_CRC = N64ID2
				
		print "File: " + File_Name
		print "Name: " + N64_Rom_Name
		print "CRC: " + N64_Rom_CRC
		print ""
		
		with open(os.path.join('txt_files',N64_Rom_CRC+'.txt'), 'r') as f:
			input = f.readlines()
		input[0] = 'Filename: '+File_Name+'\nName: '+N64_Rom_Name+'\n'
		# input[0] = 'Name: '+N64_Rom_Name+'\n'
		
		with open(N64_Rom_CRC+'.txt', 'w') as f:
			f.writelines(input)
		
		
		try:
			ini.next() # skip the comment line
			ini.next() # skip the blank line
		except: pass